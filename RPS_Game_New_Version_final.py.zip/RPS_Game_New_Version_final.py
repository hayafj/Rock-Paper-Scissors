from random import randint


class Player_movements:
    moves = ['rock', 'paper', 'scissors']

    def move(self, my_move, opponent_move):
        return my_move

    def recall(self, my_move, opponent_move):

        return my_move, opponent_move


class Human(Player_movements):

    def move(self, my_move, opponent_move):
        hmove = input("What's your play? ").lower()

        while hmove not in self.moves:
            hmove = input("Sorry try again ").lower()
        return hmove


class Copy_last_move(Player_movements):

    def move(self, my_move, opponent_move):

        if my_move == 'rock':
            return 'rock'
        if my_move == 'paper':
            return 'paper'
        else:
            return 'scissors'


class Choose_Rock(Player_movements):
    def move(self, my_move, opponent_move):
        return 'rock'


class Choose_Random(Player_movements):
    def move(self, my_move, opponent_move):
        return self.moves[randint(0, len(self.moves)-1)]


class Cycle_player(Player_movements):

    def move(self, opponent_move, my_move):
        if my_move == 'rock':
            return self.moves[1]
        if my_move == 'paper':
            return self.moves[2]
        else:
            return self.moves[0]


class Game:
    def __init__(self, human_playerr, AI_playerr):
        self.human_playerr = human_playerr
        self.AI_playerr = AI_playerr

    def winner(self, Human_move, AI_move):

        if Human_move == AI_move:
            return "No winner.\n", 0
        elif ((Human_move == 'rock' and AI_move == 'scissors') or
              (Human_move == 'scissors' and AI_move == 'paper') or
              (Human_move == 'paper' and AI_move == 'rock')):
            print("You won!\n")

            return 1
        else:

            print("Player   2 wins!\n")
            return 2

    def final_score(self, Human_score, AI_score):

        print(f"\nFinal Score\n  {Human_score} | {AI_score}\n ")
        if Human_score > AI_score:
            print('Congratulations to You!')
        if Human_score < AI_score:
            print('Congratulations to Player   2!')
        if Human_score == AI_score:
            print("It's a draw!")

    def play_round(self, current_rnd, final_rnd, Previous_Human_move,
                   Previous_AI_move):

        if current_rnd == 1:
            Human_move = self.human_playerr.move('scissors', 'rock')
            AI_move = self.AI_playerr.move('scissors', 'rock')
            print(f"Your play: {Human_move} \nPlayer 2: {AI_move}\n ")
            return Human_move, AI_move
        else:
            Human_move = self.human_playerr.move(Previous_Human_move,
                                                 Previous_AI_move)
            AI_move = self.AI_playerr.move(Previous_Human_move,
                                           Previous_AI_move)
            print(f"Your play: {Human_move} \nPlayer 2: {AI_move}\n ")
            return Human_move, AI_move

    def play_match(self):

        rounds = input('Choose the number of rounds? '
                       '*Note: from 1 - 6 rounds : ')
        while not rounds.isnumeric():

            rounds = input("Sorry try again : ")
        rounds = int(rounds)
        if rounds > 6:
            rounds = 6

        print("Let's begin!\n")
        Human_score = 0
        AI_score = 0
        Previous_Human_move = 'scissors'
        Previous_AI_move = 'paper'

        for round in range(1, rounds+1):
            print(f" Round {round}\n")
            Human_move, AI_move = self.play_round(round, rounds,
                                                  Previous_Human_move,
                                                  Previous_AI_move)
            winning_p = self.winner(Human_move, AI_move)
            Previous_Human_move,
            Previous_AI_move = self.human_playerr.recall(Human_move, AI_move)
            Previous_AI_move, p1_opp_move = self.AI_playerr.recall(AI_move,
                                                                   Human_move)
            if winning_p == 1:
                Human_score = Human_score + 1
            if winning_p == 2:
                AI_score = AI_score + 1

        self.final_score(Human_score, AI_score)
        print("\nGame over.")


if __name__ == '__main__':

    random_player_chooser = randint(1, 4)

    if random_player_chooser == 1:
        result_1 = Choose_Rock()
    if random_player_chooser == 2:
        result_1 = Choose_Random()
    if random_player_chooser == 3:
        result_1 = Cycle_player()
    if random_player_chooser == 4:
        result_1 = Copy_last_move()

    game = Game(Human(), result_1)
    game.play_match()
